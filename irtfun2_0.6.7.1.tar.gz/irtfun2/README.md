# irtfun2
------
## This package provides some usefule function.
このパッケージではIRTの分析に使える関数を使用できます。一部の関数を使用するためにはRtoolsなどのコンパイラをPCにインストールする必要があります。(最終更新：2018/11/26)

This package contains some useful function for IRT analysis. It is necessary to install c++ compiler(Rtool etc.) in your PC before use "estip" and "estheta".

筆者の英語とパッケージ作成の技術力が乏しいせいで，マニュアルを見ただけではどう使って良いかがよく分からない仕様になっています。興味のある方は直接筆者（澁谷，sep10.taku.izum(at)gmail.com）にご連絡ください。(at)を＠に変えてください。

### バージョン0.4.0での変更点。esthetaのPVsオプションで，C++による高速なリジェクションサンプリングを可能にしました。argument'sampling_engine="Cpp"'で実行可能です。

### バージョン0.6.6.1での変更点。ベイズ周辺最尤推定法を実行する機能をesthetaに追加。Bayes=1で実行できます。一般項目反応理論(General IRT)のパラメタ推定関数estGipを追加しました。GIRTについては芝（1991）「項目反応理論」の2章は6章を参照してください。

### estip
"estip" is a function for marginal maximum likelihood estimation of item parameter. For binary response data only. MML via EM is a standard estimation method in IRT item parameter estimaiton.

この関数はEMアルゴリズムを用いた周辺最尤推定法により項目パラメタを推定するためのものです。

### estheta
"estheta" is a function for estimating MLE, EAP, MAP and PVs.　Rejection sampling method is implemented for PVs sub routine.

この関数では'estip'などを使用して推定した項目パラメタを使って，受験者特性値\thetaを推定することができます。使用できるオプションにはMLE（最尤推定法），EAP（事後分布期待値），MAP（事後分布最頻値），PVs（推算値）があります。推算値の計算には棄却サンプリング法を使用しています。

### estGip
この関数は一般項目反応モデルに基づいて項目パラメタと受検者の能力パラメタ，能力パラメタの標準偏差($\phi$)などを推定します。現時点では推定の標準誤差や適合度には対応していませんが，今後対応予定です。
